const config = {
    API_BASE_URL: process.env.REACT_APP_API_URL || 'http://boostrank.me:5000',
};

export default config; 